package com.miqati.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val green = Color.rgb(7, 59, 50)
    private val cream = Color.rgb(244, 242, 233)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }
    private fun showHome() {
        val scroll = ScrollView(this).apply { setBackgroundColor(cream) }
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_HORIZONTAL; setPadding(24,28,24,24) }
        scroll.addView(root)
        root.addView(TextView(this).apply { text="۞ ميقاتي ۞"; textSize=34f; setTextColor(green); gravity=Gravity.CENTER; setPadding(0,12,0,8) }, lp())
        root.addView(TextView(this).apply { text="رفيقك إلى الصلاة والذكر والطمأنينة"; textSize=17f; setTextColor(green); gravity=Gravity.CENTER; setPadding(0,0,0,24) }, lp())
        card(root,"مواقيت الصلاة","سيتم ربط حساب المواقيت بالمدينة والإحداثيات في المرحلة التالية.")
        card(root,"الأذان والإقامة","إعداد اختيار ملفات الصوت وجدولة التنبيهات قيد الإضافة.")
        card(root,"القبلة","سيتم إضافة اتجاه القبلة باستخدام حساسات الهاتف.")
        card(root,"الأذكار","أذكار الصباح والمساء والنوم.")
        card(root,"المسبحة الإلكترونية","عداد تسبيح بسيط سيضاف في المرحلة التالية.")
        root.addView(TextView(this).apply { text="نسخة تأسيسية — ليست جميع الوظائف مفعّلة بعد."; textSize=13f; setTextColor(Color.DKGRAY); gravity=Gravity.CENTER; setPadding(0,20,0,8) },lp())
        setContentView(scroll)
    }
    private fun card(root: LinearLayout, title: String, desc: String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,16,18,16); setBackgroundColor(Color.WHITE) }
        box.addView(TextView(this).apply { text=title; textSize=21f; setTextColor(green) },lp())
        box.addView(TextView(this).apply { text=desc; textSize=15f; setTextColor(Color.DKGRAY); setPadding(0,8,0,0) },lp())
        root.addView(box,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0,0,0,14) })
    }
    private fun lp()=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)
}
